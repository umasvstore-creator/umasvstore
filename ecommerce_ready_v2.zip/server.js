const express = require('express');
const app = express();
app.use(express.json());
app.use(express.static('public'));

app.post('/order', (req,res)=>{
  console.log("Order:", req.body);
  res.send({status:"ok"});
});

app.listen(3000, ()=>console.log("Server running on 3000"));
